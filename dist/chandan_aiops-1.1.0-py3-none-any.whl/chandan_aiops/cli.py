import os
import sys
import shutil
from pathlib import Path

def main():
    """Main CLI function - THIS MUST BE CALLED main()"""
    if len(sys.argv) < 2:
        print("Usage: aiops-create <project_name>")
        sys.exit(1)
    
    project_name = sys.argv[1]
    
    # Get template directory
    package_dir = Path(__file__).parent
    template_dir = package_dir / "templates" / "aiops_project"
    
    if not template_dir.exists():
        print(f"Error: Template not found at {template_dir}")
        sys.exit(1)
    
    # Create project
    project_path = Path.cwd() / project_name
    
    if project_path.exists():
        print(f"Error: '{project_name}' already exists!")
        sys.exit(1)
    
    try:
        # Copy template
        shutil.copytree(template_dir, project_path)
        print(f"Created project: {project_name}")
        print(f"Location: {project_path}")
        
        # Show structure
        print("\nProject structure created:")
        for item in sorted(project_path.iterdir()):
            if item.is_dir():
                print(f"  {item.name}/")
            else:
                print(f"  {item.name}")
                
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()  