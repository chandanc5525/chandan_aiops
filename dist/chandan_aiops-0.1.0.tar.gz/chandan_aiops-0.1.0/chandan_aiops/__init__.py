"""
Chandan AIOps - AI/ML Operations Template Generator
"""
__version__ = "0.1.0"
__author__ = "Chandan"