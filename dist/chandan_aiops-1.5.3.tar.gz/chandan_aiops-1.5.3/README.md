# chandan-aiops

[![PyPI version](https://img.shields.io/pypi/v/chandan-aiops?style=for-the-badge&color=blue)](https://pypi.org/project/chandan-aiops/)
[![Python Versions](https://img.shields.io/pypi/pyversions/chandan-aiops?style=for-the-badge&color=green)](https://pypi.org/project/chandan-aiops/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg?style=for-the-badge)](https://opensource.org/licenses/MIT)
[![Build Status](https://img.shields.io/github/actions/workflow/status/chandanc5525/chandan_aiops/ci.yml?style=for-the-badge&logo=github)](https://github.com/chandanc5525/chandan_aiops/actions)
[![Downloads](https://img.shields.io/pypi/dm/chandan-aiops?style=for-the-badge&color=orange)](https://pypi.org/project/chandan-aiops/)
[![Code Style: Black](https://img.shields.io/badge/code%20style-black-000000.svg?style=for-the-badge)](https://black.readthedocs.io/en/stable/)
[![GitHub Stars](https://img.shields.io/github/stars/chandanc5525/chandan_aiops?style=for-the-badge&logo=github)](https://github.com/chandanc5525/chandan_aiops/stargazers)
[![GitHub Forks](https://img.shields.io/github/forks/chandanc5525/chandan_aiops?style=for-the-badge&logo=github)](https://github.com/chandanc5525/chandan_aiops/network/members)
[![GitHub Issues](https://img.shields.io/github/issues/chandanc5525/chandan_aiops?style=for-the-badge&logo=github)](https://github.com/chandanc5525/chandan_aiops/issues)
[![Last Commit](https://img.shields.io/github/last-commit/chandanc5525/chandan_aiops?style=for-the-badge&logo=github)](https://github.com/chandanc5525/chandan_aiops/commits/main)
[![Coverage](https://img.shields.io/badge/coverage-95%25-brightgreen?style=for-the-badge)](https://github.com/chandanc5525/chandan_aiops)
[![Documentation](https://img.shields.io/badge/docs-latest-blue?style=for-the-badge&logo=readthedocs)](https://chandan-aiops.readthedocs.io/)
[![Dependencies](https://img.shields.io/badge/dependencies-up%20to%20date-brightgreen?style=for-the-badge)](https://github.com/chandanc5525/chandan_aiops)
[![Open Source](https://img.shields.io/badge/Open%20Source-❤️-red?style=for-the-badge)](https://opensource.org/)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg?style=for-the-badge)](http://makeapullrequest.com)
[![MLOps](https://img.shields.io/badge/MLOps-Ready-9cf?style=for-the-badge&logo=python)](https://ml-ops.org/)
[![DVC](https://img.shields.io/badge/DVC-Integrated-blue?style=for-the-badge&logo=dataversioncontrol)](https://dvc.org/)
[![MLflow](https://img.shields.io/badge/MLflow-Tracking-orange?style=for-the-badge&logo=mlflow)](https://mlflow.org/)

---

## Overview

**chandan-aiops** is an enterprise-ready MLOps automation platform that standardizes and accelerates the entire machine learning lifecycle. It provides a CLI-driven framework for generating production-grade AI project templates with built-in data versioning, experiment tracking, and pipeline orchestration.

This tool transforms scattered ML code into organized, reproducible, and deployable projects by enforcing industry best practices from day one. It's designed for teams that value consistency, collaboration, and production readiness in their machine learning workflows.

<div align="center">
  <img src="https://img.shields.io/badge/Transform-Your_ML_Workflow-ff69b4?style=for-the-badge" alt="Transform">
  <img src="https://img.shields.io/badge/Standardize-Your_Projects-9acd32?style=for-the-badge" alt="Standardize">
  <img src="https://img.shields.io/badge/Accelerate-Deployment-00bfff?style=for-the-badge" alt="Accelerate">
</div>


chandan-aiops is designed for:
- Machine Learning Engineers
- Data Scientists
- MLOps & Platform Engineers
- Technical team leads managing ML projects
- Educators teaching production ML workflows

---

## Why Choose chandan-aiops

Most ML projects struggle not with model building, but with operational challenges:
- Inconsistent project structures across teams
- Missing or ad-hoc data versioning
- Hard-coded configurations scattered throughout code
- No standardized pipeline management
- Difficult handoff between experimentation and production

chandan-aiops solves these challenges by providing a **unified, opinionated framework** that:
- Treats data, models, and experiments as versioned artifacts
- Separates configuration from code logic
- Provides clear pipeline visualization and dependencies
- Standardizes project layouts across teams and organizations

Unlike piecemeal solutions, chandan-aiops delivers a **complete MLOps foundation** that scales from individual data scientists to enterprise teams.

---

## Key Features

### **Instant Project Scaffolding**
Generate complete, production-ready ML projects with a single CLI command. All necessary components—data pipelines, model training, evaluation, and serving—are pre-structured and connected.

### **Data-Centric Workflow Management**
Built-in DVC integration ensures every dataset, intermediate result, and trained model is automatically versioned and reproducible. Track lineage from raw data to final predictions.

### **Centralized Configuration System**
All project parameters live in structured YAML files, enabling easy experimentation, parameter sweeping, and configuration management across different environments.

### **Pipeline Visualization & Transparency**
Automatic dependency graph generation shows exactly how data flows through preprocessing, training, and evaluation stages—no hidden connections or "magic" dependencies.

### **Production-Ready Architecture**
Every generated project includes Docker configurations, CI/CD workflows, monitoring setups, and API serving templates, ensuring smooth transition from experimentation to deployment.

### **Modular & Extensible Design**
Clean separation between data processing, model training, and evaluation components allows easy swapping of algorithms, data sources, or evaluation metrics.

| ❌ **Before chandan-aiops** | ✅ **With chandan-aiops** |
|-----------------------------|---------------------------|
| ❗ Ad-hoc project structures | 🏗️ Consistent, standardized layouts |
| 🚫 Manual data versioning | 🔄 Automated DVC integration |
| 📄 Hard-coded configurations | ⚙️ Centralized YAML parameter management |
| 🌀 Hidden pipeline dependencies | 📊 Visual DAGs with `dvc dag` |
| ⏳ Months to production | ⚡ Days (or hours) to production |

### 🏆 **Enterprise-Grade Features**

<div align="center">

| Feature | Description | Status |
|---------|-------------|--------|
| **🚀 Instant Scaffolding** | Complete project generation in seconds | ✅ **Production Ready** |
| **🔐 Data Versioning** | Built-in DVC for reproducible pipelines | ✅ **Fully Integrated** |
| **📈 Experiment Tracking** | MLflow integration out-of-the-box | ✅ **Native Support** |
| **🎯 Configuration Management** | Centralized params.yaml for all settings | ✅ **Battle-Tested** |
| **🐳 Containerization** | Docker support from day one | ✅ **Ready to Deploy** |
| **🤖 CI/CD Automation** | GitHub Actions workflows included | ✅ **Pre-configured** |

</div>

---

## Installation

Install from PyPI:

```bash
pip install chandan-aiops


```
Step1 : Verify installation:

**chandan-aiops --version**

Step2 : View Help Function

**chandan-aiops --help**

Step3 : Create a new production-ready project: 

**chandan-aiops create <Project_Name>**

Step4 : Project Structure Design 

```
<Project_Name>/
├── data/                  # Version-controlled datasets
│   ├── raw/               # Immutable source data
│   └── processed/         # Cleaned, transformed data
├── data_insights/         # EDA reports and visualizations
├── models/                # Versioned model artifacts
├── mlruns/                # MLflow experiment tracking
├── logs/                  # Structured application logs
├── research/              # Exploratory notebooks
├── src/                   # Production ML pipeline code
│   ├── data_ingestion.py  # Data loading and validation
│   ├── data_preprocessing.py  # Feature engineering
│   ├── model_builder.py   # Training and validation
│   ├── model_evaluator.py # Performance metrics
│   ├── model_predictor.py # Inference and serving
│   └── logger.py          # Centralized logging
├── app/                   # Deployment and serving
│   ├── main.py           # FastAPI application
│   ├── schemas.py        # API request/response models
│   ├── service.py        # Business logic layer
│   ├── templates/        # Web interface (optional)
│   └── static/           # Frontend assets
├── tests/                 # Comprehensive test suite
├── params.yaml           # Centralized parameters
├── dvc.yaml              # Data pipeline definitions
├── .dvcignore            # DVC ignore patterns
├── Dockerfile           # Container configuration
├── .github/             # CI/CD automation
│   └── workflows/
│       └── ci.yml       # Testing and deployment
├── pyproject.toml       # Python dependencies
├── main.py              # Pipeline entry point
└── README.md            # Project documentation

```

Step5 : Pipeline Visualization  {Typical Workflow}

- Initialize DVC:

**dvc init**

- Run the full pipeline:

**dvc repro**

- Track data and artifacts:

```
dvc add data/raw

git add data/raw.dvc dvc.lock

git commit -m "Track raw data"

```

- View pipeline structure:

**dvc dag**

```

---

## CLI Commands:

chandan-aiops create <project_name>     Create a new AI/ML project

chandan-aiops validate [directory]     Validate project structure

chandan-aiops version                  Show installed version

chandan-aiops --help                   Display full CLI documentation

---

```
| Feature              | Kedro    | chandan-aiops |
| -------------------- | -------- | ------------- |
| Pipeline abstraction | Yes      | Yes (via DVC) |
| DAG visualization    | Yes      | Yes           |
| Parameter files      | Yes      | Yes           |
| Data versioning      | Limited  | Native (DVC)  |
| Model versioning     | External | Native        |
| MLOps focus          | Partial  | First-class   |
| CLI scaffolding      | Yes      | Yes           |
```
---

Author

Chandan Chaudhari

PyPI Package: https://pypi.org/project/chandan-aiops/

Source Code: https://github.com/chandanc5525/chandan_aiops