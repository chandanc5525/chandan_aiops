from setuptools import setup, find_packages
import os

# Read README
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="chandan-aiops",
    version="1.1.0",
    author="Chandan",
    author_email="your.email@example.com",
    description="Generate AI/ML project structures with one command",
    
    # For PyPI description
    long_description=long_description,
    long_description_content_type="text/markdown",
    
    packages=find_packages(),
    
    # Templates are now inside chandan_aiops package
    package_data={
        'chandan_aiops': ['templates/**/*'],
    },
    include_package_data=True,
    
    entry_points={
        'console_scripts': [
            'aiops-create=chandan_aiops.cli:main',
        ],
    },
    
    install_requires=[
        "click>=8.0.0",
    ],
    
    python_requires=">=3.7",
)