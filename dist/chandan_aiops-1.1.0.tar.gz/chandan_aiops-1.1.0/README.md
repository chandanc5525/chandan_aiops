# Chandan AIOps 
 
Generate AI/ML project structures with one command. 
