"""
Chandan AIOps - AI/ML Operations Template Generator
"""
__version__ = "1.4.0"
__author__ = "Chandan"
